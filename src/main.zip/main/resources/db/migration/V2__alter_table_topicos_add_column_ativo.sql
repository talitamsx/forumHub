ALTER TABLE topicos ADD ativo tinyint;
update topicos set ativo = 1;
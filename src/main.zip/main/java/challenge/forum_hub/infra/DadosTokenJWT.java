package challenge.forum_hub.infra;

public record DadosTokenJWT(String token) {
}

package challenge.forum_hub.controller;

import challenge.forum_hub.domain.ValidacaoException;
import challenge.forum_hub.domain.curso.Curso;
import challenge.forum_hub.domain.curso.CursoRepository;
import challenge.forum_hub.domain.topico.*;
import challenge.forum_hub.domain.usuario.Usuario;
import challenge.forum_hub.domain.usuario.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("topicos")
public class TopicoController {

    @Autowired
    private TopicoRepository topicoRepository;

    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    //cadastra tópico
    @PostMapping
    @Transactional
    public ResponseEntity<DadosDetalhamentoTopico> cadastrar (@RequestBody  @Valid DadosCadastroTopico dados, @AuthenticationPrincipal Usuario autor){
        var curso = cursoRepository.findByNome(dados.nomeCurso())
                .orElseThrow(() -> new ValidacaoException("Curso não encontrado"));

        if(topicoRepository.existsBytituloAndMensagem(dados.titulo(), dados.mensagem())){
            throw new ValidacaoException("Já existe um tópico com este título e mensagem.");
        }

        var topico = new Topico(dados, curso, autor);

        topicoRepository.save(topico);

        return ResponseEntity.status(HttpStatus.CREATED).body(new DadosDetalhamentoTopico(topico));
    }

    //Lista tópicos ativos
    @GetMapping
    public ResponseEntity<Page<DadosListagemTopico>> listar(@PageableDefault(size =10, sort = {"dataCriacao"})Pageable paginacao) {
        var page = topicoRepository.findAllByAtivoTrue(paginacao).map(DadosListagemTopico::new);
        return ResponseEntity.ok(page);
    }

    //edita tópico
    @PutMapping("{id}")
    @Transactional
    public ResponseEntity<DadosDetalhamentoTopico> atualizarInformacoes(
            @PathVariable Long id, //pega o id do topico pela URL
            @RequestBody @Valid DadosAtualizacaoTopico dados,
            @AuthenticationPrincipal Usuario autor //Usuário logado extraído do token JWT
    ){
        //busca o topico pelo ID, se ñ achar lança uma excpetion personalizada
        var topico = topicoRepository.findById(id)
                .orElseThrow(()-> new ValidacaoException("Tópico não encontrado"));

        // Verifica se o tópico está ativo
        if (Boolean.FALSE.equals(topico.getAtivo())) {
            throw new ValidacaoException("TÓPICO DELETADO, NÃO É POSSÍVEL EDITA-LO");
        }

        //verifica se usuário logado é o autor do tópico
        if(!topico.getAutor().getId().equals(autor.getId())){
            throw new ValidacaoException("VOCÊ NÃO TEM PERMISSÃO PARA EDITAR ESTE TÓPICO");
        }

        //cria uma variavel para guarda o curso editado, se o autor alterar-lo
        Curso novoCurso = null;
        //tenta buscar o nome do curso no banco
        if (dados.nomeCurso() != null && !dados.nomeCurso().isBlank()) {
            novoCurso = cursoRepository.findByNome(dados.nomeCurso())
                    .orElseThrow(()-> new ValidacaoException("Curso não encontrado"));
        }
        //chama método da entidade Tópico para realizar as alterações
        topico.atualizarInformacoes(dados, novoCurso);

        //Retorna os dados atualizados do tópico no formato de resposta
        return ResponseEntity.ok(new DadosDetalhamentoTopico(topico));
    }

    //Listar todos os tópicos
    @GetMapping("/todos")
    public ResponseEntity<Page<DadosListagemTopico>> listarTodosTopicos(
            @PageableDefault(size = 10, sort = {"id"}) Pageable paginacao){
        var page = topicoRepository.findAll(paginacao)
                .map(DadosListagemTopico::new);
        return ResponseEntity.ok(page);
    }

    //listar topico por id
    @GetMapping("/{id}")
    public ResponseEntity<DadosDetalhamentoTopico> topicoPorId(@PathVariable Long id){
        var topico = topicoRepository.findById(id)
                .orElseThrow(()-> new ValidacaoException("Tópico não encontrado"));
        return ResponseEntity.ok(new DadosDetalhamentoTopico(topico));
    }


    //deleta tópico
    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<Void> deletar(@PathVariable Long id,
                                        @AuthenticationPrincipal Usuario usuarioLogado) {
        var topico = topicoRepository.findById(id)
                .orElseThrow(() -> new ValidacaoException("Tópico não encontrado"));

        if(!topico.getAutor().getId().equals(usuarioLogado.getId())){
            throw new ValidacaoException("VOCÊ NÃO TEM PERMISSÃO PARA DELETAR ESSE TÓPICO");
        }
        topico.inativarTopico();
        return ResponseEntity.noContent().build();
    }
}

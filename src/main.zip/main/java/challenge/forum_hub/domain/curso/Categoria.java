package challenge.forum_hub.domain.curso;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

public enum Categoria {

    FRONTEND,
    BACKEND,
    DEVOPS,
    DESIGNER,

}

package challenge.forum_hub.domain.topico;

public record DadosAtualizacaoTopico (
        String titulo,
        String mensagem,
        String nomeCurso
){
}

package challenge.forum_hub.domain.usuario;

public record DadosAutenticacao(String email, String senha) {
}
